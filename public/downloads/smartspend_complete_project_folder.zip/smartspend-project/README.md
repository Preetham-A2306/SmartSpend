# SmartSpend - Complete Personal Expense Tracker Project Folder 💸

This is the complete, single-folder project package for SmartSpend containing:
1. smartspend-flutter/ - Complete Flutter & SQLite offline mobile app
2. smartspend-web/ - Complete React 19 & Tailwind v4 financial dashboard
3. docs/ - College Project Report and Viva Voce preparation materials
