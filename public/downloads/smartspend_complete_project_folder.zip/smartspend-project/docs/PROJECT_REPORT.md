# SmartSpend – Personal Expense Tracker
Academic Year: 2026 – 2027
Course: B.Tech in Computer Science & Engineering (Mini-Project)

ABSTRACT
Managing personal finances is a critical skill for college students and working professionals. SmartSpend is a fully offline, high-performance personal expense tracking mobile application developed in Flutter (Dart) with local SQLite database persistence. The application enables users to perform full CRUD operations on income and expense transactions, organize finances by categorized tags, set and monitor monthly spending limits, and visualize monthly expense distributions via graphical breakdowns. SmartSpend guarantees 100% data privacy by keeping all financial data locally on the Android device without requiring internet access, remote cloud servers, or third-party analytical APIs.

OBJECTIVES
1. Design and implement a native Android application using Google Flutter and Material Design 3.
2. Implement persistent local relational storage using SQLite (via the sqflite package) conforming to ACID principles.
3. Implement all four CRUD operations (Create, Read, Update, Delete) with parameterized queries to prevent SQL injection.
4. Provide automated financial calculations for total balance, monthly expenditures, and category-wise spending.
5. Incorporate budget management with dynamic threshold notifications when expenditures exceed user-defined limits.
6. Ensure rigorous client-side input validation and graceful empty/error state handling.

LITERATURE SURVEY
Existing personal expense trackers on mobile app stores predominantly rely on cloud-hosted backends (Firebase, Supabase, AWS DynamoDB). While cloud architectures offer multi-device sync, they present significant privacy risks, latency dependencies, and subscription costs for college students. Conversely, simple offline apps often rely on basic key-value stores (SharedPreferences), which lack indexing, aggregation functions (SUM, GROUP BY), and transaction safety. SmartSpend bridges this gap by embedding a relational SQLite database directly inside the Flutter sandbox, providing SQL performance with zero network dependency.

SYSTEM ARCHITECTURE
SmartSpend adopts a 3-tier Clean Architecture:
1. Presentation Layer (UI Widgets): Built with Flutter Material Design 3, comprising DashboardScreen, TransactionsScreen, TransactionFormScreen, ReportsScreen, and SettingsScreen. Uses StatefulWidgets for dynamic local state.
2. Business Logic / Repository Layer: Encapsulates domain rules (TransactionRepository, FinancialOverview, Category summaries) and decouples UI controllers from raw SQL statements.
3. Data Layer (SQLite Engine): Managed by DatabaseHelper (Singleton pattern) executing safe parameterized SQL queries against smartspend.db.

DATABASE SCHEMA
DATABASE NAME: smartspend.db (SQLite v3.x)

TABLE 1: transactions
• id INTEGER PRIMARY KEY AUTOINCREMENT
• type TEXT NOT NULL CHECK(type IN ('income', 'expense'))
• amount REAL NOT NULL
• description TEXT NOT NULL
• category TEXT NOT NULL
• transaction_date TEXT NOT NULL (ISO-8601: YYYY-MM-DD)
• notes TEXT (Optional)
• created_at TEXT DEFAULT CURRENT_TIMESTAMP

TABLE 2: settings
• key TEXT PRIMARY KEY
• value TEXT NOT NULL

CONCLUSION
SmartSpend successfully fulfills all requirements of a B.Tech mini-project by demonstrating native mobile development, relational database integration, and software engineering principles. The application delivers responsive user interactions, persistent SQLite storage, dynamic category-wise aggregations, and strict input validation. Future enhancements can include biometric fingerprint authentication (local_auth), automated PDF report generation, and SMS-based automated expense detection.
