# SmartSpend Viva Voce Q&A Bank (12 Questions)
### Q1. What is Flutter and what is its rendering architecture?
Answer: Flutter is Google’s open-source UI software development kit. Unlike React Native which uses a JavaScript bridge to native OEM widgets, Flutter uses its own high-performance rendering engine (Impeller / Skia) to draw every widget directly on the canvas at up to 60/120 FPS, ensuring identical look and feel across platforms.
Key Point: undefined
---

### Q2. What is the difference between a StatelessWidget and a StatefulWidget?
Answer: A StatelessWidget is immutable; its properties cannot change once built (e.g., SummaryCard, icons, static labels). A StatefulWidget maintains a mutable State object that persists across widget rebuilds; when setState() is called, Flutter triggers a dirty mark on the element and schedules build() to re-render the changed UI with new data (e.g., DashboardScreen, TransactionFormScreen).
Key Point: undefined
---

### Q3. Why did you choose SQLite over SharedPreferences or Firebase for SmartSpend?
Answer: 1. Relational querying: SQLite supports relational tables, parameterized queries, aggregate calculations (SUM, COUNT, GROUP BY), and date filtering, which SharedPreferences (simple key-value pairs) cannot perform efficiently.
2. 100% Offline & Private: Unlike Firebase Firestore which requires continuous network connectivity and API keys, SQLite is embedded locally on the Android device file system, ensuring zero latency, zero cloud costs, and complete privacy.
3. ACID Compliance: SQLite guarantees Atomicity, Consistency, Isolation, and Durability.
Key Point: undefined
---

### Q4. Explain the four CRUD operations implemented in SmartSpend.
Answer: • CREATE: DatabaseHelper.insertTransaction(model.toMap()) inserts an income or expense record into the "transactions" table, returning the autoincrement ID.
• READ: DatabaseHelper.getAllTransactions() executes query() ordered by transaction_date DESC; getFinancialOverview() aggregates SUM(amount).
• UPDATE: DatabaseHelper.updateTransaction(model) updates row fields where id = ? preserving the existing primary key.
• DELETE: DatabaseHelper.deleteTransaction(id) removes the row where id = ? following user confirmation in an AlertDialog.
Key Point: undefined
---

### Q5. Where is the smartspend.db file physically stored on an Android device?
Answer: In Android internal app storage under `/data/data/<package_name>/databases/smartspend.db`. It is private to the application process and cannot be accessed by other installed apps or normal file browsers without root privileges.
Key Point: undefined
---

### Q6. What is the purpose of database versioning and onUpgrade in DatabaseHelper?
Answer: When an app updates its schema (e.g., adding a new column or table), changing dbVersion from 1 to 2 triggers onUpgrade(db, oldVersion, newVersion). This enables ALTER TABLE migrations without dropping the existing database, preventing user data loss on app updates.
Key Point: undefined
---

### Q7. Why are SQLite operations asynchronous (Future and async/await)?
Answer: Disk I/O operations take unpredictable time compared to CPU execution. If SQLite queries were synchronous, they would block the main UI thread (Dart event loop), causing screen jank and frozen frames. Using `Future` and `async/await` offloads database I/O to background worker threads, allowing the UI to remain smooth at 60 FPS while showing progress indicators.
Key Point: undefined
---

### Q8. Why do we need to call dispose() on TextEditingControllers in TransactionFormScreen?
Answer: TextEditingControllers attach listeners to the platform text input channel. If not explicitly disposed in the State’s `dispose()` lifecycle callback, they remain in memory and cause memory leaks when the user leaves the screen.
Key Point: undefined
---

### Q9. How does SmartSpend calculate balance and handle negative balances?
Answer: Total Income is calculated using `SELECT SUM(amount) WHERE type="income"`. Total Expense is calculated using `SELECT SUM(amount) WHERE type="expense"`. Balance = Total Income - Total Expense. If total expenses exceed total income, the balance becomes negative; the UI detects this and renders the text in red (#DC2626) with an alert badge, preventing erroneous positive balance displays.
Key Point: undefined
---

### Q10. How is the monthly budget warning triggered in SmartSpend?
Answer: SmartSpend retrieves the current calendar month’s total expenses using SQL pattern matching `transaction_date LIKE "YYYY-MM%"`. If `thisMonthExpenses > monthlyBudget`, the app displays a Material 3 warning alert banner and turns the progress indicator red.
Key Point: undefined
---

### Q11. What is Material Design 3 (M3) and how did you enable it?
Answer: Material Design 3 is Google’s latest design system featuring dynamic color schemes, expressive typography, rounded cards (16-24px radius), pill-shaped segmented buttons, and modern elevation tints. We enabled it using `ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: Color(0xFF4F46E5)))`.
Key Point: undefined
---

### Q12. Why did you use the Singleton pattern for DatabaseHelper?
Answer: The Singleton pattern ensures that only one instance of `DatabaseHelper` and one open connection to `smartspend.db` exists throughout the app lifecycle. This prevents SQLite database lock errors (`database is locked`), race conditions, and duplicate open connection overhead.
Key Point: undefined
---