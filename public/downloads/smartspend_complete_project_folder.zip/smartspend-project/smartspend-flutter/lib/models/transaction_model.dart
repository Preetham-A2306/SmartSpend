class TransactionModel {
  final int? id;
  final String type; // 'income' or 'expense'
  final double amount;
  final String description;
  final String category;
  final String transactionDate; // ISO format 'YYYY-MM-DD'
  final String? notes;
  final String? createdAt;

  TransactionModel({
    this.id,
    required this.type,
    required this.amount,
    required this.description,
    required this.category,
    required this.transactionDate,
    this.notes,
    this.createdAt,
  });

  // Check if current record represents an expense
  bool get isExpense => type == 'expense';

  // Check if current record represents an income
  bool get isIncome => type == 'income';

  // Convert TransactionModel into a Map for SQLite insertion and update
  Map<String, dynamic> toMap() {
    final map = <String, dynamic>{
      'type': type,
      'amount': amount,
      'description': description,
      'category': category,
      'transaction_date': transactionDate,
      'notes': notes,
    };
    if (id != null) {
      map['id'] = id;
    }
    if (createdAt != null) {
      map['created_at'] = createdAt;
    }
    return map;
  }

  // Construct a TransactionModel from an SQLite query Map
  factory TransactionModel.fromMap(Map<String, dynamic> map) {
    return TransactionModel(
      id: map['id'] as int?,
      type: map['type'] as String,
      amount: (map['amount'] as num).toDouble(),
      description: map['description'] as String,
      category: map['category'] as String,
      transactionDate: map['transaction_date'] as String,
      notes: map['notes'] as String?,
      createdAt: map['created_at'] as String?,
    );
  }

  // Helper copyWith method for immutable state updates
  TransactionModel copyWith({
    int? id,
    String? type,
    double? amount,
    String? description,
    String? category,
    String? transactionDate,
    String? notes,
    String? createdAt,
  }) {
    return TransactionModel(
      id: id ?? this.id,
      type: type ?? this.type,
      amount: amount ?? this.amount,
      description: description ?? this.description,
      category: category ?? this.category,
      transactionDate: transactionDate ?? this.transactionDate,
      notes: notes ?? this.notes,
      createdAt: createdAt ?? this.createdAt,
    );
  }
}
