import 'package:flutter/material.dart';
import '../repositories/transaction_repository.dart';
import '../utils/formatters.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => ReportsScreenState();
}

class ReportsScreenState extends State<ReportsScreen> {
  final TransactionRepository _repository = TransactionRepository();

  DateTime _selectedMonth = DateTime.now();
  bool _isLoading = true;
  double _monthlyIncome = 0.0;
  double _monthlyExpenses = 0.0;
  List<Map<String, dynamic>> _categoryData = [];

  @override
  void initState() {
    super.initState();
    loadReportData();
  }

  Future<void> loadReportData() async {
    setState(() => _isLoading = true);
    try {
      final overview = await _repository.getFinancialOverview(_selectedMonth.year, _selectedMonth.month);
      final categories = await _repository.getMonthlyCategoryBreakdown(_selectedMonth.year, _selectedMonth.month);

      setState(() {
        _monthlyIncome = overview.thisMonthIncome;
        _monthlyExpenses = overview.thisMonthExpenses;
        _categoryData = categories;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  void _previousMonth() {
    setState(() {
      _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month - 1);
    });
    loadReportData();
  }

  void _nextMonth() {
    setState(() {
      _selectedMonth = DateTime(_selectedMonth.year, _selectedMonth.month + 1);
    });
    loadReportData();
  }

  @override
  Widget build(BuildContext context) {
    final netSavings = _monthlyIncome - _monthlyExpenses;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Monthly Reports'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Month Selector Bar
            Card(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.chevron_left),
                      onPressed: _previousMonth,
                    ),
                    Row(
                      children: [
                        const Icon(Icons.calendar_today, size: 18, color: Color(0xFF4F46E5)),
                        const SizedBox(width: 8),
                        Text(
                          Formatters.formatMonthYear(_selectedMonth),
                          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                        ),
                      ],
                    ),
                    IconButton(
                      icon: const Icon(Icons.chevron_right),
                      onPressed: _nextMonth,
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 16),

            // Summary Totals Card
            Row(
              children: [
                Expanded(
                  child: Card(
                    color: Colors.green.shade50,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Income', style: TextStyle(color: Colors.green, fontSize: 12, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(
                            Formatters.formatCurrency(_monthlyIncome),
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.green),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Card(
                    color: Colors.red.shade50,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Expenses', style: TextStyle(color: Colors.red, fontSize: 12, fontWeight: FontWeight.w600)),
                          const SizedBox(height: 6),
                          Text(
                            Formatters.formatCurrency(_monthlyExpenses),
                            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.red),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Net Savings Card
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Net Savings (Income - Expense)', style: TextStyle(fontWeight: FontWeight.w500)),
                    Text(
                      Formatters.formatCurrency(netSavings),
                      style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 16,
                        color: netSavings >= 0 ? const Color(0xFF10B981) : Colors.red,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),

            // Category Breakdown Section
            Row(
              children: [
                const Icon(Icons.pie_chart_outline, color: Color(0xFF4F46E5), size: 20),
                const SizedBox(width: 8),
                Text(
                  'Expense Breakdown by Category (${Formatters.formatMonthYear(_selectedMonth)})',
                  style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ],
            ),
            const SizedBox(height: 12),

            if (_isLoading)
              const Padding(
                padding: EdgeInsets.all(32),
                child: CircularProgressIndicator(),
              )
            else if (_categoryData.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    children: [
                      Icon(Icons.insert_chart_outlined, size: 48, color: Colors.grey.shade400),
                      const SizedBox(height: 12),
                      const Text(
                        'No expenses recorded for this month',
                        style: TextStyle(fontWeight: FontWeight.bold),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Select another month or record new expenses to view analytics.',
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                      ),
                    ],
                  ),
                ),
              )
            else
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: _categoryData.map((item) {
                      final category = item['category'] as String;
                      final amount = (item['total_amount'] as num).toDouble();
                      final count = item['count'] as int;
                      final percentage = _monthlyExpenses > 0 ? (amount / _monthlyExpenses) * 100 : 0.0;
                      final color = Formatters.getCategoryColor(category);

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    CircleAvatar(
                                      radius: 12,
                                      backgroundColor: color.withOpacity(0.15),
                                      child: Icon(Formatters.getCategoryIcon(category), size: 14, color: color),
                                    ),
                                    const SizedBox(width: 8),
                                    Text(category, style: const TextStyle(fontWeight: FontWeight.w600)),
                                    const SizedBox(width: 6),
                                    Text('($count trans.)', style: TextStyle(color: Colors.grey.shade500, fontSize: 11)),
                                  ],
                                ),
                                Text(
                                  '${Formatters.formatCurrency(amount)} (${percentage.toStringAsFixed(1)}%)',
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(6),
                              child: LinearProgressIndicator(
                                value: (percentage / 100).clamp(0.0, 1.0),
                                minHeight: 8,
                                backgroundColor: Colors.grey.shade100,
                                valueColor: AlwaysStoppedAnimation<Color>(color),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
