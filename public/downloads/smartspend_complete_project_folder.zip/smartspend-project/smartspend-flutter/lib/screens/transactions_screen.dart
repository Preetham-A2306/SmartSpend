import 'package:flutter/material.dart';
import '../repositories/transaction_repository.dart';
import '../models/transaction_model.dart';
import '../widgets/transaction_tile.dart';
import 'transaction_form_screen.dart';

class TransactionsScreen extends StatefulWidget {
  final VoidCallback onDataChanged;

  const TransactionsScreen({
    super.key,
    required this.onDataChanged,
  });

  @override
  State<TransactionsScreen> createState() => TransactionsScreenState();
}

class TransactionsScreenState extends State<TransactionsScreen> {
  final TransactionRepository _repository = TransactionRepository();

  bool _isLoading = true;
  List<TransactionModel> _allTransactions = [];
  List<TransactionModel> _filteredTransactions = [];

  String _searchQuery = '';
  String _selectedType = 'all'; // 'all', 'income', 'expense'
  String _selectedCategory = 'all';

  @override
  void initState() {
    super.initState();
    loadTransactions();
  }

  Future<void> loadTransactions() async {
    setState(() => _isLoading = true);
    try {
      final items = await _repository.getTransactions();
      setState(() {
        _allTransactions = items;
        _applyFilters();
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  void _applyFilters() {
    List<TransactionModel> list = [..._allTransactions];

    // Filter by type
    if (_selectedType != 'all') {
      list = list.where((t) => t.type == _selectedType).toList();
    }

    // Filter by category
    if (_selectedCategory != 'all') {
      list = list.where((t) => t.category == _selectedCategory).toList();
    }

    // Filter by search query (description or notes)
    if (_searchQuery.trim().isNotEmpty) {
      final query = _searchQuery.toLowerCase().trim();
      list = list.where((t) {
        final descMatch = t.description.toLowerCase().contains(query);
        final notesMatch = t.notes?.toLowerCase().contains(query) ?? false;
        final catMatch = t.category.toLowerCase().contains(query);
        return descMatch || notesMatch || catMatch;
      }).toList();
    }

    _filteredTransactions = list;
  }

  Future<void> _deleteTransaction(TransactionModel item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Transaction'),
        content: Text('Are you sure you want to permanently delete "${item.description}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true && item.id != null) {
      await _repository.deleteTransaction(item.id!);
      loadTransactions();
      widget.onDataChanged();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Transaction deleted successfully'),
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  Future<void> _editTransaction(TransactionModel item) async {
    final updated = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (context) => TransactionFormScreen(existingTransaction: item),
      ),
    );

    if (updated == true) {
      loadTransactions();
      widget.onDataChanged();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('All Transactions'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: SearchBar(
              hintText: 'Search by description or category...',
              leading: const Icon(Icons.search, size: 20),
              trailing: _searchQuery.isNotEmpty
                  ? [
                      IconButton(
                        icon: const Icon(Icons.clear, size: 18),
                        onPressed: () {
                          setState(() {
                            _searchQuery = '';
                            _applyFilters();
                          });
                        },
                      ),
                    ]
                  : null,
              elevation: const WidgetStatePropertyAll(0),
              backgroundColor: WidgetStatePropertyAll(Colors.grey.shade100),
              onChanged: (val) {
                setState(() {
                  _searchQuery = val;
                  _applyFilters();
                });
              },
            ),
          ),
        ),
      ),
      body: Column(
        children: [
          // Filter Chips
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(
              children: [
                FilterChip(
                  label: const Text('All'),
                  selected: _selectedType == 'all',
                  onSelected: (selected) {
                    setState(() {
                      _selectedType = 'all';
                      _applyFilters();
                    });
                  },
                ),
                const SizedBox(width: 8),
                FilterChip(
                  label: const Text('Expenses Only'),
                  selected: _selectedType == 'expense',
                  selectedColor: Colors.red.shade100,
                  onSelected: (selected) {
                    setState(() {
                      _selectedType = selected ? 'expense' : 'all';
                      _applyFilters();
                    });
                  },
                ),
                const SizedBox(width: 8),
                FilterChip(
                  label: const Text('Income Only'),
                  selected: _selectedType == 'income',
                  selectedColor: Colors.green.shade100,
                  onSelected: (selected) {
                    setState(() {
                      _selectedType = selected ? 'income' : 'all';
                      _applyFilters();
                    });
                  },
                ),
              ],
            ),
          ),
          const Divider(height: 1),

          // Transactions List
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredTransactions.isEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.search_off_rounded, size: 54, color: Colors.grey.shade400),
                            const SizedBox(height: 12),
                            const Text(
                              'No matching transactions found',
                              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              _searchQuery.isNotEmpty
                                  ? 'Try adjusting your search or filters'
                                  : 'No records exist in the SQLite database',
                              style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                            ),
                          ],
                        ),
                      )
                    : ListView.builder(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        itemCount: _filteredTransactions.length,
                        itemBuilder: (context, index) {
                          final item = _filteredTransactions[index];
                          return TransactionTile(
                            transaction: item,
                            onTap: () => _editTransaction(item),
                            onDelete: () => _deleteTransaction(item),
                          );
                        },
                      ),
          ),
        ],
      ),
    );
  }
}
