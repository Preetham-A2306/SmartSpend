import 'package:flutter/material.dart';
import '../repositories/transaction_repository.dart';
import '../models/transaction_model.dart';
import '../widgets/summary_card.dart';
import '../widgets/transaction_tile.dart';
import '../utils/formatters.dart';
import 'transaction_form_screen.dart';

class DashboardScreen extends StatefulWidget {
  final VoidCallback onNavigateToTransactions;
  final VoidCallback onNavigateToReports;

  const DashboardScreen({
    super.key,
    required this.onNavigateToTransactions,
    required this.onNavigateToReports,
  });

  @override
  State<DashboardScreen> createState() => DashboardScreenState();
}

class DashboardScreenState extends State<DashboardScreen> {
  final TransactionRepository _repository = TransactionRepository();

  bool _isLoading = true;
  FinancialOverview? _overview;
  List<TransactionModel> _recentTransactions = [];
  List<Map<String, dynamic>> _categoryBreakdown = [];

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    setState(() => _isLoading = true);
    final now = DateTime.now();

    try {
      final overview = await _repository.getFinancialOverview(now.year, now.month);
      final allTransactions = await _repository.getTransactions();
      final breakdown = await _repository.getMonthlyCategoryBreakdown(now.year, now.month);

      setState(() {
        _overview = overview;
        _recentTransactions = allTransactions.take(5).toList();
        _categoryBreakdown = breakdown;
        _isLoading = false;
      });
    } catch (e) {
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error loading dashboard: $e')),
        );
      }
    }
  }

  Future<void> _deleteTransaction(TransactionModel item) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Transaction'),
        content: Text('Do you want to permanently delete "${item.description}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true && item.id != null) {
      await _repository.deleteTransaction(item.id!);
      loadData();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Transaction deleted'),
            backgroundColor: Colors.black87,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    }
  }

  Future<void> _editTransaction(TransactionModel item) async {
    final updated = await Navigator.push<bool>(
      context,
      MaterialPageRoute(
        builder: (context) => TransactionFormScreen(existingTransaction: item),
      ),
    );

    if (updated == true) {
      loadData();
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(
        body: Center(
          child: CircularProgressIndicator(),
        ),
      );
    }

    final overview = _overview!;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'SmartSpend',
              style: TextStyle(
                color: Theme.of(context).colorScheme.primary,
                fontWeight: FontWeight.w800,
                fontSize: 22,
              ),
            ),
            const Text(
              'Personal Expense Tracker',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'Refresh',
            onPressed: loadData,
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: loadData,
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          children: [
            // Hero Financial Card
            SummaryCard(
              balance: overview.currentBalance,
              totalIncome: overview.totalIncome,
              totalExpenses: overview.totalExpenses,
              thisMonthExpenses: overview.thisMonthExpenses,
              monthlyBudget: overview.monthlyBudget,
              isBudgetExceeded: overview.isBudgetExceeded,
            ),
            const SizedBox(height: 20),

            // Monthly Budget Progress Bar
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          "This Month's Spending",
                          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
                        ),
                        Text(
                          '${Formatters.formatCurrency(overview.thisMonthExpenses)} / ${Formatters.formatCurrency(overview.monthlyBudget)}',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w600,
                            color: overview.isBudgetExceeded ? Colors.red : Colors.grey.shade700,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: overview.budgetProgress,
                        minHeight: 10,
                        backgroundColor: Colors.grey.shade200,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          overview.isBudgetExceeded ? Colors.red : const Color(0xFF4F46E5),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Category Expense Breakdown preview
            if (_categoryBreakdown.isNotEmpty) ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Top Spending Categories',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                  ),
                  TextButton(
                    onPressed: widget.onNavigateToReports,
                    child: const Text('View Report'),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: _categoryBreakdown.take(3).map((item) {
                      final category = item['category'] as String;
                      final amount = (item['total_amount'] as num).toDouble();
                      final total = overview.thisMonthExpenses > 0 ? overview.thisMonthExpenses : 1.0;
                      final percentage = (amount / total) * 100;
                      final color = Formatters.getCategoryColor(category);

                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Icon(Formatters.getCategoryIcon(category), size: 16, color: color),
                                    const SizedBox(width: 8),
                                    Text(category, style: const TextStyle(fontWeight: FontWeight.w500, fontSize: 13)),
                                  ],
                                ),
                                Text(
                                  '${Formatters.formatCurrency(amount)} (${percentage.toStringAsFixed(0)}%)',
                                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                                ),
                              ],
                            ),
                            const SizedBox(height: 6),
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: (percentage / 100).clamp(0.0, 1.0),
                                minHeight: 6,
                                backgroundColor: Colors.grey.shade100,
                                valueColor: AlwaysStoppedAnimation<Color>(color),
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ),
              const SizedBox(height: 20),
            ],

            // Recent Transactions Section
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Recent Transactions',
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
                TextButton(
                  onPressed: widget.onNavigateToTransactions,
                  child: const Text('View All'),
                ),
              ],
            ),
            const SizedBox(height: 8),

            if (_recentTransactions.isEmpty)
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(32),
                  child: Column(
                    children: [
                      Icon(Icons.account_balance_wallet_outlined, size: 48, color: Colors.grey.shade400),
                      const SizedBox(height: 12),
                      const Text(
                        'No transactions recorded yet',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Tap the "+ Add" button below to add your first income or expense record.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.grey.shade600, fontSize: 13),
                      ),
                    ],
                  ),
                ),
              )
            else
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: _recentTransactions.length,
                itemBuilder: (context, index) {
                  final item = _recentTransactions[index];
                  return TransactionTile(
                    transaction: item,
                    onTap: () => _editTransaction(item),
                    onDelete: () => _deleteTransaction(item),
                  );
                },
              ),
            const SizedBox(height: 60), // Spacing for FAB
          ],
        ),
      ),
    );
  }
}
