import 'package:flutter/material.dart';
import '../repositories/transaction_repository.dart';
import '../utils/formatters.dart';

class SettingsScreen extends StatefulWidget {
  final VoidCallback onDataReset;

  const SettingsScreen({
    super.key,
    required this.onDataReset,
  });

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  final TransactionRepository _repository = TransactionRepository();
  final TextEditingController _budgetController = TextEditingController();

  double _currentBudget = 15000.0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadBudget();
  }

  @override
  void dispose() {
    _budgetController.dispose();
    super.dispose();
  }

  Future<void> _loadBudget() async {
    final b = await _repository.getBudget();
    setState(() {
      _currentBudget = b;
      _budgetController.text = b.toStringAsFixed(0);
      _isLoading = false;
    });
  }

  Future<void> _saveBudget() async {
    final val = double.tryParse(_budgetController.text.trim());
    if (val == null || val <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a valid budget greater than ₹0')),
      );
      return;
    }

    await _repository.saveBudget(val);
    setState(() {
      _currentBudget = val;
    });

    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Monthly budget updated to ${Formatters.formatCurrency(val)}'),
          backgroundColor: const Color(0xFF10B981),
        ),
      );
    }
  }

  Future<void> _clearAllData() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Clear All Data?'),
        content: const Text(
          'This will permanently delete all recorded transactions from the SQLite database (smartspend.db). This action cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: FilledButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Clear Everything'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _repository.clearAllTransactions();
      widget.onDataReset();
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('All transactions deleted from SQLite database'),
            backgroundColor: Colors.black87,
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings & Configuration'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // Monthly Budget Card
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.savings_outlined, color: Color(0xFF4F46E5)),
                      SizedBox(width: 8),
                      Text(
                        'Monthly Spending Budget',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Set your monthly expense limit. SmartSpend alerts you when spending exceeds this amount.',
                    style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: TextField(
                          controller: _budgetController,
                          keyboardType: TextInputType.number,
                          decoration: InputDecoration(
                            prefixText: '₹ ',
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                            contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),
                      FilledButton(
                        onPressed: _saveBudget,
                        style: FilledButton.styleFrom(
                          backgroundColor: const Color(0xFF4F46E5),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        child: const Text('Update'),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Database & Storage Info
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.storage_outlined, color: Color(0xFF4F46E5)),
                      SizedBox(width: 8),
                      Text(
                        'SQLite Database Details',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text('Database File'),
                    subtitle: Text('smartspend.db (Android /data/data/.../databases/)'),
                  ),
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text('SQLite Engine'),
                    subtitle: Text('sqflite 2.3.2 with WAL mode'),
                  ),
                  const ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text('Data Privacy'),
                    subtitle: Text('100% Offline. No internet permissions required.'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          // Danger Zone
          Card(
            color: Colors.red.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(Icons.warning_amber_rounded, color: Colors.red.shade700),
                      const SizedBox(width: 8),
                      Text(
                        'Data Management',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.red.shade700),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Clear all transaction records while keeping table structure and budget settings intact.',
                    style: TextStyle(fontSize: 12, color: Colors.red.shade900),
                  ),
                  const SizedBox(height: 14),
                  FilledButton.icon(
                    onPressed: _clearAllData,
                    icon: const Icon(Icons.delete_forever),
                    label: const Text('Clear All Transactions'),
                    style: FilledButton.styleFrom(
                      backgroundColor: Colors.red.shade600,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
