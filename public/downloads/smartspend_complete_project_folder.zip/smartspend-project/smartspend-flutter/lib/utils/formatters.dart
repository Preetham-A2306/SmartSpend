import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class Formatters {
  // Format numbers to Indian Rupee currency standard
  static String formatCurrency(double amount) {
    final format = NumberFormat.currency(
      locale: 'en_IN',
      symbol: '₹',
      decimalDigits: 2,
    );
    return format.format(amount);
  }

  // Format ISO date (YYYY-MM-DD) to friendly format '28 Oct 2026'
  static String formatDate(String isoDateString) {
    try {
      final date = DateTime.parse(isoDateString);
      return DateFormat('dd MMM yyyy').format(date);
    } catch (e) {
      return isoDateString;
    }
  }

  // Format month and year e.g., 'October 2026'
  static String formatMonthYear(DateTime date) {
    return DateFormat('MMMM yyyy').format(date);
  }

  // Categories list
  static const List<String> expenseCategories = [
    'Food',
    'Transport',
    'Shopping',
    'Education',
    'Entertainment',
    'Bills',
    'Healthcare',
    'Travel',
    'Other',
  ];

  static const List<String> incomeCategories = [
    'Salary',
    'Allowance',
    'Scholarship',
    'Freelance',
    'Gift',
    'Other',
  ];

  // Category Icon resolver
  static IconData getCategoryIcon(String category) {
    switch (category) {
      case 'Food':
        return Icons.restaurant;
      case 'Transport':
        return Icons.directions_bus;
      case 'Shopping':
        return Icons.shopping_bag;
      case 'Education':
        return Icons.school;
      case 'Entertainment':
        return Icons.movie;
      case 'Bills':
        return Icons.receipt_long;
      case 'Healthcare':
        return Icons.medical_services;
      case 'Travel':
        return Icons.flight_takeoff;
      case 'Salary':
        return Icons.work;
      case 'Allowance':
        return Icons.savings;
      case 'Scholarship':
        return Icons.military_tech;
      case 'Freelance':
        return Icons.laptop_mac;
      case 'Gift':
        return Icons.card_giftcard;
      default:
        return Icons.category;
    }
  }

  // Category Color resolver
  static Color getCategoryColor(String category) {
    switch (category) {
      case 'Food':
        return const Color(0xFFEF4444);
      case 'Transport':
        return const Color(0xFFF97316);
      case 'Shopping':
        return const Color(0xFFEC4899);
      case 'Education':
        return const Color(0xFF8B5CF6);
      case 'Entertainment':
        return const Color(0xFFA855F7);
      case 'Bills':
        return const Color(0xFFEAB308);
      case 'Healthcare':
        return const Color(0xFF06B6D4);
      case 'Travel':
        return const Color(0xFF3B82F6);
      case 'Salary':
        return const Color(0xFF10B981);
      case 'Allowance':
        return const Color(0xFF14B8A6);
      case 'Scholarship':
        return const Color(0xFF6366F1);
      case 'Freelance':
        return const Color(0xFF22C55E);
      case 'Gift':
        return const Color(0xFFF43F5E);
      default:
        return const Color(0xFF64748B);
    }
  }
}
