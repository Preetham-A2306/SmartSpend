import 'dart:async';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/transaction_model.dart';

class DatabaseHelper {
  // Singleton pattern to ensure only a single instance of the database exists
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  static const String dbName = 'smartspend.db';
  static const int dbVersion = 1;

  // Table and column names
  static const String tableTransactions = 'transactions';
  static const String colId = 'id';
  static const String colType = 'type';
  static const String colAmount = 'amount';
  static const String colDescription = 'description';
  static const String colCategory = 'category';
  static const String colDate = 'transaction_date';
  static const String colNotes = 'notes';
  static const String colCreatedAt = 'created_at';

  static const String tableSettings = 'settings';
  static const String colKey = 'key';
  static const String colValue = 'value';

  DatabaseHelper._init();

  // Asynchronously get or initialize the SQLite database
  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB(dbName);
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    // Get default databases directory for Android
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: dbVersion,
      onCreate: _createDB,
      onUpgrade: _upgradeDB,
    );
  }

  // Schema creation
  Future<void> _createDB(Database db, int version) async {
    // 1. Transactions Table
    await db.execute('''
      CREATE TABLE $tableTransactions (
        $colId INTEGER PRIMARY KEY AUTOINCREMENT,
        $colType TEXT NOT NULL CHECK($colType IN ('income', 'expense')),
        $colAmount REAL NOT NULL,
        $colDescription TEXT NOT NULL,
        $colCategory TEXT NOT NULL,
        $colDate TEXT NOT NULL,
        $colNotes TEXT,
        $colCreatedAt TEXT DEFAULT CURRENT_TIMESTAMP
      )
    ''');

    // 2. Settings Table for local key-value persistence (e.g. monthly budget)
    await db.execute('''
      CREATE TABLE $tableSettings (
        $colKey TEXT PRIMARY KEY,
        $colValue TEXT NOT NULL
      )
    ''');

    // Seed default monthly budget of ₹15,000 for convenience
    await db.insert(tableSettings, {
      colKey: 'monthly_budget',
      colValue: '15000.0',
    });
  }

  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    // Handle schema migrations for future updates without dropping user data
    if (oldVersion < 2) {
      // Future migration example:
      // await db.execute('ALTER TABLE $tableTransactions ADD COLUMN tags TEXT;');
    }
  }

  // --- CRUD OPERATIONS FOR TRANSACTIONS ---

  // CREATE: Insert a new transaction
  Future<int> insertTransaction(TransactionModel transaction) async {
    final db = await instance.database;
    return await db.insert(
      tableTransactions,
      transaction.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // READ: Fetch all transactions ordered by date descending
  Future<List<TransactionModel>> getAllTransactions() async {
    final db = await instance.database;
    final result = await db.query(
      tableTransactions,
      orderBy: '$colDate DESC, $colId DESC',
    );
    return result.map((json) => TransactionModel.fromMap(json)).toList();
  }

  // READ: Fetch a single transaction by ID
  Future<TransactionModel?> getTransactionById(int id) async {
    final db = await instance.database;
    final maps = await db.query(
      tableTransactions,
      where: '$colId = ?',
      whereArgs: [id],
    );

    if (maps.isNotEmpty) {
      return TransactionModel.fromMap(maps.first);
    }
    return null;
  }

  // UPDATE: Update an existing transaction record by ID
  Future<int> updateTransaction(TransactionModel transaction) async {
    final db = await instance.database;
    return await db.update(
      tableTransactions,
      transaction.toMap(),
      where: '$colId = ?',
      whereArgs: [transaction.id],
    );
  }

  // DELETE: Remove a single transaction by ID
  Future<int> deleteTransaction(int id) async {
    final db = await instance.database;
    return await db.delete(
      tableTransactions,
      where: '$colId = ?',
      whereArgs: [id],
    );
  }

  // DELETE ALL: Clear all records for settings reset
  Future<int> deleteAllTransactions() async {
    final db = await instance.database;
    return await db.delete(tableTransactions);
  }

  // --- AGGREGATIONS & SUMMARY QUERIES ---

  // Sum total income
  Future<double> getTotalIncome() async {
    final db = await instance.database;
    final result = await db.rawQuery(
      'SELECT SUM($colAmount) as total FROM $tableTransactions WHERE $colType = ?',
      ['income'],
    );
    final val = result.first['total'];
    return val != null ? (val as num).toDouble() : 0.0;
  }

  // Sum total expenses
  Future<double> getTotalExpenses() async {
    final db = await instance.database;
    final result = await db.rawQuery(
      'SELECT SUM($colAmount) as total FROM $tableTransactions WHERE $colType = ?',
      ['expense'],
    );
    final val = result.first['total'];
    return val != null ? (val as num).toDouble() : 0.0;
  }

  // Sum monthly expenses for a given year and month (format: YYYY-MM)
  Future<double> getMonthlyExpenses(int year, int month) async {
    final db = await instance.database;
    final monthStr = month.toString().padLeft(2, '0');
    final pattern = '$year-$monthStr%';

    final result = await db.rawQuery(
      'SELECT SUM($colAmount) as total FROM $tableTransactions WHERE $colType = ? AND $colDate LIKE ?',
      ['expense', pattern],
    );
    final val = result.first['total'];
    return val != null ? (val as num).toDouble() : 0.0;
  }

  // Sum monthly income for a given year and month
  Future<double> getMonthlyIncome(int year, int month) async {
    final db = await instance.database;
    final monthStr = month.toString().padLeft(2, '0');
    final pattern = '$year-$monthStr%';

    final result = await db.rawQuery(
      'SELECT SUM($colAmount) as total FROM $tableTransactions WHERE $colType = ? AND $colDate LIKE ?',
      ['income', pattern],
    );
    final val = result.first['total'];
    return val != null ? (val as num).toDouble() : 0.0;
  }

  // Get category breakdown for expenses in a given month
  Future<List<Map<String, dynamic>>> getCategoryWiseExpenses(int year, int month) async {
    final db = await instance.database;
    final monthStr = month.toString().padLeft(2, '0');
    final pattern = '$year-$monthStr%';

    return await db.rawQuery('''
      SELECT $colCategory, SUM($colAmount) as total_amount, COUNT($colId) as count
      FROM $tableTransactions
      WHERE $colType = 'expense' AND $colDate LIKE ?
      GROUP BY $colCategory
      ORDER BY total_amount DESC
    ''', [pattern]);
  }

  // --- SETTINGS STORAGE (BUDGET) ---

  Future<double> getMonthlyBudget() async {
    final db = await instance.database;
    final result = await db.query(
      tableSettings,
      where: '$colKey = ?',
      whereArgs: ['monthly_budget'],
    );
    if (result.isNotEmpty) {
      final valStr = result.first[colValue] as String?;
      return double.tryParse(valStr ?? '15000') ?? 15000.0;
    }
    return 15000.0;
  }

  Future<void> setMonthlyBudget(double budget) async {
    final db = await instance.database;
    await db.insert(
      tableSettings,
      {
        colKey: 'monthly_budget',
        colValue: budget.toString(),
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // Close database connection cleanly when app terminates
  Future<void> close() async {
    final db = await instance.database;
    db.close();
  }
}
