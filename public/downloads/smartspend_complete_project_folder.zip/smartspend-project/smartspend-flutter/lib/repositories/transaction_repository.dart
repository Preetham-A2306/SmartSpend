import '../database/database_helper.dart';
import '../models/transaction_model.dart';

class TransactionRepository {
  final DatabaseHelper _dbHelper = DatabaseHelper.instance;

  // Insert transaction
  Future<int> addTransaction(TransactionModel transaction) {
    return _dbHelper.insertTransaction(transaction);
  }

  // Get all transactions
  Future<List<TransactionModel>> getTransactions() {
    return _dbHelper.getAllTransactions();
  }

  // Get single transaction
  Future<TransactionModel?> getTransaction(int id) {
    return _dbHelper.getTransactionById(id);
  }

  // Update transaction
  Future<int> updateTransaction(TransactionModel transaction) {
    return _dbHelper.updateTransaction(transaction);
  }

  // Delete transaction
  Future<int> deleteTransaction(int id) {
    return _dbHelper.deleteTransaction(id);
  }

  // Clear all records
  Future<int> clearAllTransactions() {
    return _dbHelper.deleteAllTransactions();
  }

  // Get financial overview
  Future<FinancialOverview> getFinancialOverview(int year, int month) async {
    final totalIncome = await _dbHelper.getTotalIncome();
    final totalExpenses = await _dbHelper.getTotalExpenses();
    final currentBalance = totalIncome - totalExpenses;
    final monthlyExpenses = await _dbHelper.getMonthlyExpenses(year, month);
    final monthlyIncome = await _dbHelper.getMonthlyIncome(year, month);
    final budget = await _dbHelper.getMonthlyBudget();

    return FinancialOverview(
      totalIncome: totalIncome,
      totalExpenses: totalExpenses,
      currentBalance: currentBalance,
      thisMonthExpenses: monthlyExpenses,
      thisMonthIncome: monthlyIncome,
      monthlyBudget: budget,
    );
  }

  // Get category breakdown
  Future<List<Map<String, dynamic>>> getMonthlyCategoryBreakdown(int year, int month) {
    return _dbHelper.getCategoryWiseExpenses(year, month);
  }

  // Budget settings
  Future<double> getBudget() => _dbHelper.getMonthlyBudget();
  Future<void> saveBudget(double budget) => _dbHelper.setMonthlyBudget(budget);
}

class FinancialOverview {
  final double totalIncome;
  final double totalExpenses;
  final double currentBalance;
  final double thisMonthExpenses;
  final double thisMonthIncome;
  final double monthlyBudget;

  FinancialOverview({
    required this.totalIncome,
    required this.totalExpenses,
    required this.currentBalance,
    required this.thisMonthExpenses,
    required this.thisMonthIncome,
    required this.monthlyBudget,
  });

  bool get isBudgetExceeded => monthlyBudget > 0 && thisMonthExpenses > monthlyBudget;

  double get budgetProgress {
    if (monthlyBudget <= 0) return 0.0;
    return (thisMonthExpenses / monthlyBudget).clamp(0.0, 1.0);
  }
}
