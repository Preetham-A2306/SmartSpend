import 'package:flutter_test/flutter_test.dart';
import 'package:smartspend/models/transaction_model.dart';

void main() {
  group('TransactionModel Tests', () {
    test('toMap and fromMap preserves all fields correctly', () {
      final model = TransactionModel(
        id: 101,
        type: 'expense',
        amount: 850.50,
        description: 'Semester Exam Fee',
        category: 'Education',
        transactionDate: '2026-10-28',
        notes: 'Paid via UPI',
      );

      final map = model.toMap();
      final reconstructed = TransactionModel.fromMap(map);

      expect(reconstructed.id, 101);
      expect(reconstructed.type, 'expense');
      expect(reconstructed.amount, 850.50);
      expect(reconstructed.description, 'Semester Exam Fee');
      expect(reconstructed.category, 'Education');
      expect(reconstructed.transactionDate, '2026-10-28');
      expect(reconstructed.notes, 'Paid via UPI');
      expect(reconstructed.isExpense, true);
      expect(reconstructed.isIncome, false);
    });

    test('copyWith modifies only targeted properties', () {
      final original = TransactionModel(
        id: 1,
        type: 'income',
        amount: 5000,
        description: 'Freelance',
        category: 'Freelance',
        transactionDate: '2026-10-01',
      );

      final updated = original.copyWith(amount: 6500, description: 'Freelance Mobile App');

      expect(updated.id, 1);
      expect(updated.amount, 6500);
      expect(updated.description, 'Freelance Mobile App');
      expect(updated.category, 'Freelance');
    });
  });
}
