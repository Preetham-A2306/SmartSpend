# SmartSpend – Personal Expense Tracker

A complete, beginner-friendly Flutter mobile application for tracking personal income, expenses, and monthly budgets using a local SQLite database (`sqflite`).

## Tech Stack
- **Framework**: Flutter (Dart 3.x)
- **Database**: SQLite (`sqflite: ^2.3.2`, `path: ^1.9.0`)
- **UI Design**: Material Design 3
- **Formatters**: `intl: ^0.19.0` for ₹ INR and Indian date formatting
- **Platform**: Android (Offline, zero network requirement)

## Quick Start (Terminal Commands)
```bash
# 1. Create a new Flutter project
flutter create --org com.smartspend smartspend
cd smartspend

# 2. Add dependencies
flutter pub add sqflite path intl cupertino_icons

# 3. Verify Flutter setup
flutter doctor

# 4. Run on connected Android device or emulator
flutter run
```
