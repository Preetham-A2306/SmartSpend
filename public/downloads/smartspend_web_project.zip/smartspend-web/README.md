# SmartSpend – Personal Expense Tracker (Web App) 💸

A modern, responsive, and visually delightful Personal Expense Tracker built with React 19, TypeScript, Tailwind CSS v4, and Recharts.

## Features
- 💰 **Real-Time Financial Dashboard**: Total Balance, Total Income, Total Expenses, and Savings rate.
- 📊 **Pastel Analytics & Charts**: Income vs Expenses bar chart, Category distribution doughnut, Monthly spending trend.
- 💳 **Complete CRUD Transactions**: Add, edit, delete, search, filter by category/type, sort by date, and export to CSV.
- 🎯 **Budget Planner**: Monthly spending limit, category-wise budgets, health alerts (green/amber/red), and 50/30/20 tips.
- ⚙️ **Data Persistence**: Offline-first local storage with one-click JSON backup and restore.
- 📁 **Single Folder Project Export**: 1-click download of the complete codebase as a ready-to-run folder.

## Quick Start
```bash
# 1. Install dependencies
npm install

# 2. Start development server
npm run dev

# 3. Open in your browser
# Visit http://localhost:3000
```
